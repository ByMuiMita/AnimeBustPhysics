package com.example.animebustphysics.client;

import net.minecraft.client.model.Dilation;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;

/**
 * Minecraft 1.20.1 model based on the cuboids and pivots in
 * AnimeBustPhysics_Model.bbmodel. The Blockbench file is retained in the
 * project as the editable source; Minecraft renders this Java representation.
 */
public final class BustModel {
    private static final float INITIAL_PITCH = (float) Math.toRadians(5.0);

    public final ModelPart root;
    public final ModelPart torso;
    public final ModelPart leftBone;
    public final ModelPart rightBone;

    public BustModel(ModelPart root) {
        this.root = root;
        this.torso = root.getChild("torso");
        this.leftBone = root.getChild("left_bone");
        this.rightBone = root.getChild("right_bone");
    }

    public static TexturedModelData getTexturedModelData() {
        ModelData data = new ModelData();
        var root = data.getRoot();

        // Blockbench torso: (-6, 0, -4) to (2, 14, 0).
        // X is shifted +2 and Z is mirrored/shifted to face Minecraft's front.
        root.addChild("torso",
            ModelPartBuilder.create().uv(0, 0)
                .cuboid(-4.0F, 0.0F, -2.0F, 8.0F, 14.0F, 4.0F, new Dilation(0.0F)),
            ModelTransform.NONE);

        // LeftBone pivot from Blockbench [0, 11, 0] -> Minecraft [2, 11, -2].
        // LeftPart is 4 x 4 x 3 and remains independently animated.
        root.addChild("left_bone",
            ModelPartBuilder.create().uv(16, 0)
                .cuboid(-2.0F, -2.0F, -2.0F, 4.0F, 4.0F, 3.0F, new Dilation(0.0F)),
            ModelTransform.of(2.0F, 11.0F, -2.0F, INITIAL_PITCH, 0.0F, 0.0F));

        // RightBone pivot from Blockbench [-4, 11, 0] -> Minecraft [-2, 11, -2].
        root.addChild("right_bone",
            ModelPartBuilder.create().uv(32, 0)
                .cuboid(-2.0F, -2.0F, -2.0F, 4.0F, 4.0F, 3.0F, new Dilation(0.0F)),
            ModelTransform.of(-2.0F, 11.0F, -2.0F, INITIAL_PITCH, 0.0F, 0.0F));

        return TexturedModelData.of(data, 64, 64);
    }
}
