package com.example.animebustphysics.client;

import net.minecraft.client.model.Dilation;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;

/**
 * Minecraft 1.20.1 model based on the cuboids and pivots in
 * AnimeBustPhysics_Model.bbmodel. The Blockbench file is retained in the
 * project as the editable source; Minecraft renders this Java representation.
 */
public final class BustModel {
    private static final float INITIAL_PITCH = (float) Math.toRadians(5.0);

    public final ModelPart root;
    public final ModelPart torso;
    public final ModelPart leftBone;
    public final ModelPart rightBone;

    public BustModel(ModelPart root) {
        this.root = root;
        this.torso = root.getChild("torso");
        this.leftBone = root.getChild("left_bone");
        this.rightBone = root.getChild("right_bone");
    }

    public static TexturedModelData getTexturedModelData() {
        ModelData data = new ModelData();
        ModelPart root = data.getRoot();

        // Keep an empty torso part for the vanilla body transform; rendering a
        // second full torso here would z-fight with the player's own skin.
        root.addChild("torso", ModelPartBuilder.create(), ModelTransform.NONE);

        // Place the two cosmetic parts on the upper chest (Minecraft model Y
        // increases downward). Their UVs sample the player's torso skin region.
        root.addChild("left_bone",
            ModelPartBuilder.create().uv(20, 20)
                .cuboid(-2.0F, -2.0F, -2.25F, 4.0F, 4.0F, 3.0F, new Dilation(0.02F)),
            ModelTransform.of(2.0F, 5.0F, -2.0F, INITIAL_PITCH, 0.0F, 0.0F));

        root.addChild("right_bone",
            ModelPartBuilder.create().uv(20, 20)
                .cuboid(-2.0F, -2.0F, -2.25F, 4.0F, 4.0F, 3.0F, new Dilation(0.02F)),
            ModelTransform.of(-2.0F, 5.0F, -2.0F, INITIAL_PITCH, 0.0F, 0.0F));

        return TexturedModelData.of(data, 64, 64);
    }
}
