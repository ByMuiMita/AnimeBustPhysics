package com.example.animebustphysics.client;

/** Independent damped-spring state for one rendered player. */
public final class PhysicsManager {
    private final SpringPoint left = new SpringPoint();
    private final SpringPoint right = new SpringPoint();

    private double previousVelocityX;
    private double previousVelocityY;
    private double previousVelocityZ;
    private boolean hasPreviousVelocity;

    public void tick(double velocityX, double velocityY, double velocityZ) {
        final double dt = 1.0 / 20.0;
        if (!hasPreviousVelocity) {
            previousVelocityX = velocityX;
            previousVelocityY = velocityY;
            previousVelocityZ = velocityZ;
            hasPreviousVelocity = true;
            return;
        }

        double accelerationX = clamp((velocityX - previousVelocityX) / dt, -40.0, 40.0);
        double accelerationY = clamp((velocityY - previousVelocityY) / dt, -40.0, 40.0);
        double accelerationZ = clamp((velocityZ - previousVelocityZ) / dt, -40.0, 40.0);
        double sensitivity = PhysicsConfig.MOVEMENT_SENSITIVITY;
        // Add a small velocity-driven component so the model continues to react
        // during steady walking, not only on the first acceleration tick.
        double horizontalSpeed = Math.sqrt(velocityX * velocityX + velocityZ * velocityZ);
        double walkSway = Math.sin((System.nanoTime() / 1_000_000_000.0) * 10.0)
            * Math.min(horizontalSpeed, 0.22) * 0.12;

        double verticalTarget = clamp(-accelerationY * sensitivity * 0.20, -0.12, 0.12);
        double sideTarget = clamp(accelerationX * sensitivity + walkSway, -0.12, 0.12);
        double forwardTarget = clamp(-accelerationZ * sensitivity * 0.35, -0.06, 0.06);

        left.update(clamp(sideTarget + forwardTarget, -0.16, 0.16), verticalTarget, dt);
        right.update(clamp(-sideTarget + forwardTarget, -0.16, 0.16), verticalTarget, dt);

        previousVelocityX = velocityX;
        previousVelocityY = velocityY;
        previousVelocityZ = velocityZ;
    }

    public void reset() {
        left.reset();
        right.reset();
        hasPreviousVelocity = false;
    }

    public SpringPoint getLeft() { return left; }
    public SpringPoint getRight() { return right; }

    private static double clamp(double value, double min, double max) {
        return Math.max(min, Math.min(max, value));
    }
}
