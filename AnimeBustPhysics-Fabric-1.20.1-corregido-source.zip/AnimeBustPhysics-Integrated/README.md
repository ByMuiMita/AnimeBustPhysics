# Anime Bust Physics — Fabric 1.20.1

Client-side prototype for Minecraft 1.20.1, Java 17 and Fabric.

## Included
- Blockbench source model: `AnimeBustPhysics_Model.bbmodel`.
- Java model representation with torso and two independent pivots based on the Blockbench cuboids.
- Per-player client-side spring simulation (each viewer simulates players they can see).
- Player feature renderer and bundled texture at `assets/bustphysics/textures/entity/anime_bust_texture.png`.
- Fabric Loom 1.6.12 configuration.

## Important limitations
- Minecraft does not load `.bbmodel` files at runtime. `BustModel.java` is the in-game Java representation; the `.bbmodel` remains the editable source. The geometry is mapped from its cuboids and pivots, but UVs are represented using Minecraft's cuboid UV layout and may need visual adjustment in-game.
- Physics is cosmetic and client-side. Every client simulates visible players locally; it is not synchronized by the server and requires the mod on each viewing client.
- The supplied texture is a provisional 64x64 atlas. Confirm its appearance in-game and adjust UV mapping if needed.
- This source package has not been compiled or tested in a Minecraft client in this environment. It is not a verified JAR.

## Build
Use JDK 17 and Gradle 8.x, then run `gradle build`. The resulting JAR should appear in `build/libs/` if dependency resolution and compilation succeed.
