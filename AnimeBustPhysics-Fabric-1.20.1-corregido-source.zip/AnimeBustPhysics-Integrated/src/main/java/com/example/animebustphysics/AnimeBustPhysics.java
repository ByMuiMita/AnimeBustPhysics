package com.example.animebustphysics;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class AnimeBustPhysics implements ModInitializer {
    public static final String MOD_ID = "bustphysics";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("Anime Bust Physics prototype loaded.");
    }
}
