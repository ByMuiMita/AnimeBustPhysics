package com.example.animebustphysics.client;

/**
 * Initial lightweight tuning values. These are prototype values, not
 * final in-game sliders yet.
 */
public final class PhysicsConfig {
    private PhysicsConfig() {}

    public static double STIFFNESS = 22.0;
    public static double DAMPING = 7.0;
    public static double MOVEMENT_SENSITIVITY = 0.018;
    public static double MAX_OFFSET = 0.18;
}
