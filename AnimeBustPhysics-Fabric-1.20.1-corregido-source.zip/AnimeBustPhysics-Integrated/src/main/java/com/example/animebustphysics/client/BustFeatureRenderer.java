package com.example.animebustphysics.client;

import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

/** Draws the custom geometry as a feature attached to each player's torso. */
public final class BustFeatureRenderer extends FeatureRenderer<AbstractClientPlayerEntity, PlayerEntityModel<AbstractClientPlayerEntity>> {
    private static final Identifier TEXTURE = new Identifier("bustphysics", "textures/entity/anime_bust_texture.png");
    private final BustModel bust;

    public BustFeatureRenderer(FeatureRendererContext<AbstractClientPlayerEntity, PlayerEntityModel<AbstractClientPlayerEntity>> context) {
        super(context);
        this.bust = new BustModel(BustModel.getTexturedModelData().createModel());
    }

    @Override
    public void render(MatrixStack matrices, VertexConsumerProvider vertices, int light,
                       AbstractClientPlayerEntity player, float limbAngle, float limbDistance,
                       float tickDelta, float animationProgress, float headYaw, float headPitch) {
        if (player.isInvisible()) return;

        PhysicsManager physics = AnimeBustPhysicsClient.physicsFor(player.getUuid());
        SpringPoint left = physics.getLeft();
        SpringPoint right = physics.getRight();

        // Follow the vanilla torso transform, then apply independent spring rotations.
        matrices.push();
        getContextModel().body.rotate(matrices);

        bust.leftBone.pitch = (float) (Math.toRadians(5.0) + left.getY());
        bust.leftBone.roll = (float) left.getX();
        bust.rightBone.pitch = (float) (Math.toRadians(5.0) + right.getY());
        bust.rightBone.roll = (float) right.getX();

        VertexConsumer consumer = vertices.getBuffer(RenderLayer.getEntityCutoutNoCull(TEXTURE));
        bust.torso.render(matrices, consumer, light, OverlayTexture.DEFAULT_UV);
        bust.leftBone.render(matrices, consumer, light, OverlayTexture.DEFAULT_UV);
        bust.rightBone.render(matrices, consumer, light, OverlayTexture.DEFAULT_UV);
        matrices.pop();
    }
}
