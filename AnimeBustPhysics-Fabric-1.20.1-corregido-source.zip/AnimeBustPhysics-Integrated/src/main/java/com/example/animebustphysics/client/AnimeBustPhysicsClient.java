package com.example.animebustphysics.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.LivingEntityFeatureRendererRegistrationCallback;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.entity.model.PlayerEntityModel;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Client entrypoint; keeps a separate cosmetic simulation for every player. */
public final class AnimeBustPhysicsClient implements ClientModInitializer {
    private static final Map<UUID, PhysicsManager> PHYSICS = new HashMap<>();

    public static PhysicsManager physicsFor(UUID playerId) {
        return PHYSICS.computeIfAbsent(playerId, ignored -> new PhysicsManager());
    }

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.world == null) {
                PHYSICS.clear();
                return;
            }

            Set<UUID> activePlayers = new HashSet<>();
            client.world.getPlayers().forEach(player -> {
                UUID id = player.getUuid();
                activePlayers.add(id);
                physicsFor(id).tick(player.getVelocity().x, player.getVelocity().y, player.getVelocity().z);
            });
            PHYSICS.keySet().retainAll(activePlayers);
        });

        LivingEntityFeatureRendererRegistrationCallback.EVENT.register((entityType, renderer, helper, context) -> {
            if (renderer instanceof PlayerEntityRenderer) {
                @SuppressWarnings("unchecked")
                LivingEntityRenderer<AbstractClientPlayerEntity, PlayerEntityModel<AbstractClientPlayerEntity>> playerRenderer =
                    (LivingEntityRenderer<AbstractClientPlayerEntity, PlayerEntityModel<AbstractClientPlayerEntity>>) (LivingEntityRenderer<?, ?>) renderer;
                helper.register(new BustFeatureRenderer(playerRenderer));
            }
        });
    }
}
