package com.example.animebustphysics.client;

/**
 * A small 2D damped-spring simulation.
 * Coordinates are normalized offsets that a future model renderer can use.
 */
public final class SpringPoint {
    private double x;
    private double y;
    private double velocityX;
    private double velocityY;

    public void update(double targetX, double targetY, double deltaSeconds) {
        double dt = Math.min(deltaSeconds, 0.05);

        double ax = PhysicsConfig.STIFFNESS * (targetX - x)
            - PhysicsConfig.DAMPING * velocityX;
        double ay = PhysicsConfig.STIFFNESS * (targetY - y)
            - PhysicsConfig.DAMPING * velocityY;

        velocityX += ax * dt;
        velocityY += ay * dt;

        x += velocityX * dt;
        y += velocityY * dt;

        x = clamp(x, -PhysicsConfig.MAX_OFFSET, PhysicsConfig.MAX_OFFSET);
        y = clamp(y, -PhysicsConfig.MAX_OFFSET, PhysicsConfig.MAX_OFFSET);
    }

    public void reset() {
        x = 0.0;
        y = 0.0;
        velocityX = 0.0;
        velocityY = 0.0;
    }

    public double getX() { return x; }
    public double getY() { return y; }

    private static double clamp(double value, double min, double max) {
        return Math.max(min, Math.min(max, value));
    }
}
